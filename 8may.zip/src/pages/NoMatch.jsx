import React from 'react'

function NoMatch() {
  return (
    <div>
        <img src="https://img.freepik.com/free-vector/404-error-design-with-yellow-robot_23-2147733248.jpg?size=626&ext=jpg&ga=GA1.1.27319698.1696070793&semt=ais" alt="" />
        <h1>404! NOT FOUND</h1>
    </div>
  )
}

export default NoMatch